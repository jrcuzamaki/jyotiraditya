x=10
y=12
z=x+y
print("the value after addition:",z)
