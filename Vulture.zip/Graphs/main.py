
dataset = []
#data = sorted(dataset)
x = None

if x == int:
    while True:
        x = int(input())
        dataset.append(x)
else:
    print(type(x))

