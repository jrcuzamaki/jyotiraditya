num1=int(input("give first number:"))
num2=int(input("give second number:"))
sum=num1+num2
sub=num1-num2
mul=num1*num2
div=num1/num2
rem=num1%num2
print("the result after addition is:",sum)
print("the result after substraction is:",sub)
print("the result after multiplication is:",mul)
print("the result after division is:",div)
print("the result after reminder is:",rem)
